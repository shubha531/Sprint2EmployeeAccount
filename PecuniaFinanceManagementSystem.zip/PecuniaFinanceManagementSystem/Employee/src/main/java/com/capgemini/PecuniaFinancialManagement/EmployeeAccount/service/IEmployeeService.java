package com.capgemini.PecuniaFinancialManagement.EmployeeAccount.service;

import java.util.List;

import com.capgemini.PecuniaFinancialManagement.EmployeeAccount.entity.Employee;

public interface IEmployeeService {

	
	public boolean save(Employee employee);
	public List<Employee> getEmployees();
	public boolean delete(Employee employee);
	public List<Employee> getEmployeeByID(Employee employee);
	public boolean updateEmployee(Employee employee);
}
