package com.capgemini.PecuniaFinancialManagement.EmployeeAccount.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee")
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private long employee_id;
	private String employee_name;
	private String employee_contact;
	private String employee_designation;
	
	private String employee_DOB;
	private String employee_gender;
	private String employee_address;
	private String employee_city;
	private String employee_state;
	private String employee_pincode;
	private String employee_pan;
	private String employee_adhaar;
	
	public Employee() {
		  
    }
 
    public Employee(String employee_name, String employee_contact, String employee_designation,String employee_DOB,
    		String employee_gender,String employee_address,String employee_city,String employee_state,String employee_pincode,
    		String employee_pan,String employee_adhaar)
    {
         this.employee_name = employee_name;
         this.employee_contact=employee_contact;
         this.employee_designation=employee_designation;
         this.employee_DOB=employee_DOB;
         this.employee_gender=employee_gender;
         this.employee_address=employee_address;
         this.employee_city=employee_city;
         this.employee_state=employee_state;
         this.employee_pincode=employee_pincode;
         this.employee_pan=employee_pan;
         this.employee_adhaar=employee_adhaar;
         
    }
    

	public long getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	
    @Column(name = "employee_name")
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	   @Column(name = "employee_contact")
	public String getEmployee_contact() {
		return employee_contact;
	}
	public void setEmployee_contact(String employee_contact) {
		this.employee_contact = employee_contact;
	}
	   @Column(name = "employee_DOB")
	public String getEmployee_DOB() {
		return employee_DOB;
	}
	public void setEmployee_DOB(String employee_DOB) {
		this.employee_DOB = employee_DOB;
	}
	   @Column(name = "employee_gender")
	public String getEmployee_gender() {
		return employee_gender;
	}
	public void setEmployee_gender(String employee_gender) {
		this.employee_gender = employee_gender;
	}
	   @Column(name = "employee_address")
	public String getEmployee_address() {
		return employee_address;
	}
	public void setEmployee_address(String employee_address) {
		this.employee_address = employee_address;
	}
	   @Column(name = "employee_city")
	public String getEmployee_city() {
		return employee_city;
	}
	public void setEmployee_city(String employee_city) {
		this.employee_city = employee_city;
	}
	   @Column(name = "employee_state")
	public String getEmployee_state() {
		return employee_state;
	}
	public void setEmployee_state(String employee_state) {
		this.employee_state = employee_state;
	}
	   @Column(name = "employee_pincode")
	public String getEmployee_pincode() {
		return employee_pincode;
	}
	public void setEmployee_pincode(String employee_pincode) {
		this.employee_pincode = employee_pincode;
	}
	   @Column(name = "employee_pan")
	public String getEmployee_pan() {
		return employee_pan;
	}
	public void setEmployee_pan(String employee_pan) {
		this.employee_pan = employee_pan;
	}
	   @Column(name = "employee_adhaar")
	public String getEmployee_adhaar() {
		return employee_adhaar;
	}
	public void setEmployee_adhaar(String employee_adhaar) {
		this.employee_adhaar = employee_adhaar;
	}
	
	   @Column(name = "employee_designation")
	public String getEmployee_designation() {
		return employee_designation;
	}
	public void setEmployee_designation(String employee_designation) {
		this.employee_designation = employee_designation;
	}
}
