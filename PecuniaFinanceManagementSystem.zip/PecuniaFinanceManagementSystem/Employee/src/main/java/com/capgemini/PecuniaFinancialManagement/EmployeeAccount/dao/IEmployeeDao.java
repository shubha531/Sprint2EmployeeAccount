package com.capgemini.PecuniaFinancialManagement.EmployeeAccount.dao;

import java.util.List;

import com.capgemini.PecuniaFinancialManagement.EmployeeAccount.entity.Employee;

public interface IEmployeeDao {

	public List<Employee> getEmployees();
	public List<Employee> getEmployeeByID(Employee employee);
	public boolean updateEmployee(Employee employee);
	public boolean save(Employee employee);
	boolean delete(Employee employee);
}
