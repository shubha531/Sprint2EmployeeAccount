package com.capgemini.PecuniaFinancialManagement.EmployeeAccount.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.PecuniaFinancialManagement.EmployeeAccount.dao.IEmployeeDao;
import com.capgemini.PecuniaFinancialManagement.EmployeeAccount.entity.Employee;

@Service
@Transactional
public class EmployeeServiceImpl implements IEmployeeService {
 
	@Autowired
	private IEmployeeDao employeedao;
	
	@Override
	public boolean save(Employee employee) {
		return employeedao.save(employee);
	}

	@Override
	public List<Employee> getEmployees() {
		return employeedao.getEmployees();
	}

	@Override
	public boolean delete(Employee employee) {
		return employeedao.delete(employee);
	}

	@Override
	public List<Employee> getEmployeeByID(Employee employee) {
		return employeedao.getEmployeeByID(employee);
	}

	@Override
	public boolean updateEmployee(Employee employee) {
		return employeedao.updateEmployee(employee);
	}

}
